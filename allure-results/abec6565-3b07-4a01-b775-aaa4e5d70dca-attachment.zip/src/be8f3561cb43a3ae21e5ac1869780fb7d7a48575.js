const{test,expect} = require ('@playwright/test')

const loginURL = 'https://uat-dxn.aviatorsms.com/';
const dashboardURL = 'https://uat-dxn.aviatorsms.com/Menus.aspx';

const username = 'lsg_222';
const password = 'welcome';
//zoom size
    /**
 * @param {import('@playwright/test').Page} page
 */
async function setZoom80(page) {
    await page.evaluate(() => {
        document.documentElement.style.zoom = '90%';
    });
}
// Equipment Management navigation
/**
 * @param {import('@playwright/test').Page} page
 */
async function openEquipmentManagement(page) {

    await page.locator('xpath=//*[@id="form1"]/div[4]/div[4]').click();

    await page.locator('xpath=//*[@id="div5_Liparent1"]/a').click();

    await page.locator('xpath=//*[@id="div5_ul1"]/li[1]/a/span').click();

    await setZoom80(page);
    
}
 function generateVehicleNumber(){
const state='AP';
const distrit='31';
const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const letter1 = letters[Math.floor(Math.random()*26)];
const letter2 = letters[Math.floor(Math.random()*26)];
const number = Math.floor(Math.random()*1000).toString().padStart(4,'0');
return`${state} ${distrit} ${letter1}${letter2} ${number}`;
 }
    //login 
    /**
 * @param {import('@playwright/test').Page} page
 */
    async function login(page) {
      await page.goto(loginURL);
      await  setZoom80(page);
      await page.locator("//*[@id='txt_Username']").fill(username);
       await page.locator("//*[@id='txt_Password']").fill(password);
  await page.locator("//*[@id='btn_Login']").click();
  await expect(page).toHaveURL(dashboardURL);
//   await setZoom80(page);
  await  openEquipmentManagement(page);
    }
    test('login function', async ({ page }) => {
      await login(page);
    })
    test.describe('aviator sms', ()=>{
test.beforeEach(async ({page}) =>{
await login(page);
})

 test.only('Request Application', async ({ page }) => {

    const vehicleNumber = generateVehicleNumber();
    await page.locator("//*[@id='ctl00_ContentPlaceHolder1_Pane_1_content_txt_3988_OF']").fill(vehicleNumber);
     await page.waitForTimeout(3000);
    await page.locator("//*[@id='ctl00_ContentPlaceHolder1_Pane_1_content_ddl_5747_ME_842']").selectOption({index:2});
    await page.waitForTimeout(3000);
    await page.locator("//*[@id='ctl00_ContentPlaceHolder1_Pane_1_content_ddl_5749_ME_844']").selectOption({index:2});
    await page.waitForTimeout(5000);
    await page.locator("//*[@id='ctl00_ContentPlaceHolder1_Pane_1_content_txt_2157_OF']").pressSequentially('CRANE');
   await page.waitForTimeout(3000);
   console.log(await page.locator("//*[@id='ctl00_ContentPlaceHolder1_Pane_1_content_ddl_5750_ME_845']").allTextContents());
   await page.waitForTimeout(3000);
     await page.locator("//*[@id='ctl00_ContentPlaceHolder1_Pane_1_content_ddl_5750_ME_845']").selectOption({label: 'Rotary Slasher'});
    await page.waitForTimeout(3000);
    await page.evaluate(() => {
    window.scrollBy(0,1100);
});
//  const attachs = page.locator(
//     '#ctl00_ContentPlaceHolder1_Pane_1_content_btn_2244_OF'
// );



// await attachs.scrollIntoViewIfNeeded();

// await expect(attachs).toBeVisible({ timeout: 15000 });

// console.log('Attachments visible:', await attachs.isVisible());

// await attachs.click();
// const context = page.context();

// context.on('page', async newPage => {
//     console.log('New page detected:', newPage.url());

//     newPage.on('close', () => {
//         console.log('Child page closed');
//     });

//     newPage.on('crash', () => {
//         console.log('Child page crashed');
//     });
// });

// page.on('dialog', async dialog => {
//     console.log('Dialog detected:', dialog.message());
//     await dialog.accept();
// });
// const Attachments = page.locator(
//     '#ctl00_ContentPlaceHolder1_Pane_1_content_btn_2244_OF'
// );

// await Attachments.scrollIntoViewIfNeeded();
// await Attachments.click();

// await page.waitForTimeout(5000);

// console.log('Total pages:', context.pages().length);
const attach = page.locator(
    '#ctl00_ContentPlaceHolder1_Pane_1_content_btn_2244_OF'
);

// Check button
await expect(attach).toBeVisible();
await expect(attach).toBeEnabled();

// Click Attach
await attach.click();

// Wait for the modal/popup content
await page.locator('#ctl00_ContentPlaceHolder1_pB.cpBody')
    .waitFor({ state: 'visible', timeout: 15000 });

console.log('Attachment popup content detected');
const parentPage = page;

const [childPage] = await Promise.all([
    page.waitForEvent('popup'),
    page.locator(
        '#ctl00_ContentPlaceHolder1_Pane_1_content_btn_2244_OF'
    ).click()
]);

await childPage.waitForLoadState('domcontentloaded');

console.log('Popup opened:', childPage.url());

// Work inside the popup
await childPage.bringToFront();
 });
})

